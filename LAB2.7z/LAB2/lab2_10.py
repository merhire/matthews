n = 50
a = 0
b = 1

while a <= n:
    print(a, " ")
    c = a
    a = b
    b = c + b
    