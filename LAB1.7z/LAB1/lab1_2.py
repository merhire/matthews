name = "Matvey"
age = 19
fav_color = "grey"

print(name, age, fav_color)