int = 12
float = 12.2
str = "hello"
list = ["red", "green", "yellow"]
tuple = (10, 20)
dict = {"color": "red", "year": "2025"}
set = {1,2,3,4}

print(int, "-",type(int))
print(float, "-",type(float))
print(str, "-",type(str))
print(tuple, "-",type(tuple))
print(dict, "-",type(dict))
print(set, "-",type(set))